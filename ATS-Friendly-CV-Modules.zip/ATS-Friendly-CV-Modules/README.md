# ATS-Friendly-CV-Modules

> **Sentez-önce, audit-düzeltmeli ATS-CV motoru.** Dağınık kaynakları (iki Claude skill'i, üç Drive araştırma dokümanı, Grammarly SEO/ATS ansiklopedisi) tek bir çalışır mühendislik deposunda birleştirir: bir iş ilanını **çöz** (ANALİZ), adayın gerçek kariyer verisiyle **yeniden bağla** (SENTEZ), sonra **ölç ve doğrula** (SKOR + GAP).

Çıktı dili: **Türkçe** (istenirse değişir). Lisans: Proprietary.

---

## Neden bu depo?
Bilgi üç yerde dağınıktı: Claude skill'leri, akademik Drive araştırmaları ve Grammarly ansiklopedisi. Bu depo hepsini **tek doğruluk kaynağında** toplar, çelişkileri denetler (audit), ve metodolojiyi **çalışan Python motoruna** dönüştürür. Çekirdek motor sıfır zorunlu bağımlılıkla çalışır.

## Mimari (kuş bakışı)
```
JD ─▶ Katman 0 Alım+Provenans ─▶ 1 Bütünsel kavrama ─▶ 2 ANALİZ (7 katman)
                                                          │
Framework CV (kanıt bankası) ───────────────────────────┼─▶ 3 SKOR & GAP
                                                          │
                              4 SENTEZ (küme+XYZ+provenans) ◀┘ ─▶ 5 Doğrula ─▶ 6 ALAN
```
6 alan: `keywords · analysis · summary · synthesis · match_score · gap_analysis`. Detay: [`docs/00-mimari.md`](docs/00-mimari.md).

## Depo yapısı
```
engine/        Çalışan ATS motoru (ats_engine paketi + data + examples + tests)
docs/          Birleşik bilgi tabanı (mimari, metodoloji, skor matematiği, Grammarly analizi, audit)
  research/    Üç kaynak araştırmanın atıflı/damıtılmış özeti
skills/        İki Claude skill'i (ats-cv-architect, synthesis-analysis-research) BİREBİR + eval
prompts/       Taşınabilir Master Prompt (her LLM) + 6 alan şablonu
templates/     Etiketli JD şablonu + kanıt bankası şablonu
workflows/     n8n pipeline + Notion 6-DB şeması
```

## Hızlı başlangıç
```bash
cd engine
python examples/run_demo.py          # uçtan uca demo (SBERT'siz)
python -m pytest -q                  # 19 test
python -m ats_engine.cli report --jd examples/sample_jd_foreign_trade.txt \
    --framework examples/framework_cv.md --cv examples/sample_cv.txt --no-sbert --format md
```
SBERT (semantik katman) için: `pip install -e "engine[semantic]"`. Kurulu değilse motor zarifçe SBERT'siz çalışır.

## Çekirdek ilkeler
- **Dürüstlük/provenans mutlak** — her CV maddesi kanıt bankasına bağlanır; bağlanamayan çıkar.
- **Coverage > density** — anahtar kelime doldurma yok; hedef skor **%75–85** (>%90 = şişirme).
- **Skor = proxy** — tescilli ATS formüllerinin yaklaşıklaması, mutlak gerçek değil.
- **H1 düzeltmesi** — revizyon döngüsü `skor≥hedef VEYA kapatılabilir-gap=0` ile durur (sonsuz döngü yok).

## Grammarly karşılaştırması
Grammarly ansiklopedisi sistemi çürütmedi, **güçlendirdi**: 700+ aktif fiil + synonym/LSI + fuzzy matching motora **veri** olarak aktarıldı (`engine/data/*.json`). Tam analiz: [`docs/05-grammarly-entegrasyonu.md`](docs/05-grammarly-entegrasyonu.md).

## Sürüm
v1.0.0 — Birleştirme. Bkz. [`CHANGELOG.md`](CHANGELOG.md).
