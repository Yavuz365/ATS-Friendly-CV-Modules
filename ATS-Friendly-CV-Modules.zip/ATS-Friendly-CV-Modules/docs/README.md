# docs/ — Bilgi Tabanı (Knowledge Base)

Bu klasör, dağınık kaynakların (iki Claude skill'i, iki Drive araştırma dokümanı, Grammarly SEO/ATS ansiklopedisi) **birleştirilmiş ve damıtılmış** anlatısıdır. Ham kaynaklar `skills/` altında birebir korunur; burada ise bunların tek bir tutarlı sisteme nasıl oturduğu anlatılır.

| Dosya | İçerik |
|---|---|
| `00-mimari.md` | Sistemin kuş bakışı mimarisi + diyalektik döngü |
| `01-metodoloji.md` | "Önce Sentez, Sonra Analiz" — epistemolojik temel |
| `02-jd-decomposition.md` | İş ilanının 7 katmanlı ayrıştırması (ANALİZ) |
| `03-skorlama-matematigi.md` | TF-IDF, BM25, kosinüs, hibrit skor (denetim-düzeltmeli) |
| `04-sentez-kurallari.md` | Kümeleme, XYZ/CAR, kanıt bankası, anti-stuffing (SENTEZ) |
| `05-grammarly-entegrasyonu.md` | **Grammarly ansiklopedisi ile karşılaştırma + motora ne aktarıldı** |
| `06-denetim-ve-duzeltmeler.md` | Audit bulguları (H1, H2, M1–M4, D1–D4) ve düzeltmeler |
| `07-workflow-multitool.md` | Drive + çok-LLM + n8n + Notion iş akışı |
| `research/` | Üç kaynak araştırmanın damıtılmış özeti (atıflı) |
