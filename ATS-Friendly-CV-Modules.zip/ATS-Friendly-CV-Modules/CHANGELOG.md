# CHANGELOG

## [1.0.0] — Birleştirme (Unification)
İlk birleşik sürüm. Dağınık kaynaklar (iki Claude skill'i, Drive araştırma
dokümanları, Grammarly SEO/ATS ansiklopedisi) tek bir "mühendislik" deposunda
toplandı ve çalışır bir Python motoruna dönüştürüldü.

### Eklendi
- `engine/ats_engine/` — çalışır ATS motoru (BM25, TF-IDF kosinüs, eşanlamlı-duyarlı
  kapsama, 7 katmanlı JD ayrıştırma, kanıt bankası/provenans, sentez, 6 alanlı rapor, CLI).
- `engine/data/` — Grammarly'den türetilmiş aksiyon-fiil kütüphanesi + beceri/LSI eşanlamlı haritası.
- `engine/examples/` + `engine/tests/` — uçtan uca demo ve 19 testlik pytest paketi.
- `skills/` — iki Claude skill'i (ats-cv-architect, synthesis-analysis-research) birebir + eval'ler.
- `docs/` — mimari, metodoloji, skorlama matematiği, sentez kuralları, Grammarly analizi, audit/düzeltmeler.
- `prompts/`, `templates/`, `workflows/` — master prompt, şablonlar, n8n/Notion iş akışları.

### Düzeltildi (audit)
- **H1 (sonsuz döngü):** durma koşulu `skor≥hedef VEYA kapatılabilir-gap=0` olarak düzeltildi.
- `parse_gate` toplam terim değil **çarpan/kapı**; skor `clamp(0,1)`.
- Kapsama eşanlamlı-duyarlı; kapatılabilir/kapatılamaz gap ayrımı (dürüstlük kuralı).
