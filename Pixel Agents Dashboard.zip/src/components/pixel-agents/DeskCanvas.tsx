import { useAgentData } from '@/context/AgentDataContext';
import { AgentSprite } from './AgentSprite';
import type { AgentEntry } from '@/types/pixelAgents';
import { STATE_COLOR_VAR } from '@/types/pixelAgents';

const SEAT_COLORS = [
  'hsl(160 84% 52%)', // main: brand green
  'hsl(195 90% 60%)',
  'hsl(38 95% 58%)',
  'hsl(280 80% 65%)',
  'hsl(350 85% 62%)',
  'hsl(150 80% 50%)',
];

const SEATS = 6;

function Desk({ seatIndex, agent }: { seatIndex: number; agent?: AgentEntry }) {
  const stateVar = agent ? STATE_COLOR_VAR[agent.state] : '--muted-foreground';
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="h-20 flex items-end justify-center">
        {agent && (
          <AgentSprite
            agent={agent}
            bodyColor={SEAT_COLORS[seatIndex % SEAT_COLORS.length]}
            walking={agent.state === 'spawning'}
          />
        )}
      </div>
      {/* Monitor */}
      <div
        className="w-14 h-9 rounded-sm relative anim-monitor"
        style={{
          ['--state-color' as never]: `var(${stateVar})`,
          background: agent
            ? `linear-gradient(180deg, hsl(var(${stateVar}) / 0.35), hsl(var(--surface-3)))`
            : 'hsl(var(--surface-3))',
          border: '2px solid hsl(var(--border))',
        }}
      >
        <div
          className="absolute inset-1 overflow-hidden"
          style={{ background: 'hsl(230 40% 4%)' }}
        >
          {agent && (
            <div
              className="w-full h-[2px]"
              style={{ background: `hsl(var(${stateVar}) / 0.8)`, animation: 'scan 1.5s linear infinite' }}
            />
          )}
        </div>
      </div>
      <div className="w-2 h-2 bg-secondary" />
      {/* Desk */}
      <div className="w-20 h-3 bg-secondary border-x border-b border-border" />
      {/* Seat label */}
      <span className="text-[9px] font-pixel text-muted-foreground">
        SEAT-{String(seatIndex).padStart(2, '0')}
      </span>
    </div>
  );
}

export function DeskCanvas() {
  const { agents } = useAgentData();
  const list = Array.from(agents.values());
  const main = list.find((a) => a.role === 'main');
  const subs = list.filter((a) => a.role === 'sub');

  const seated: (AgentEntry | undefined)[] = new Array(SEATS).fill(undefined);
  seated[0] = main;
  subs.slice(0, SEATS - 1).forEach((s, i) => {
    seated[i + 1] = s;
  });

  const overflow = subs.length - (SEATS - 1);

  return (
    <div className="relative bg-card border border-border rounded-md p-4 scanlines overflow-hidden">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-pixel text-xs text-foreground">// MASA GÖRÜNÜMÜ</h3>
        <span className="text-[10px] text-muted-foreground">{list.length} ajan</span>
      </div>

      <div
        className="rounded-sm p-4"
        style={{
          background:
            'linear-gradient(180deg, hsl(230 30% 8%), hsl(230 30% 5%))',
          backgroundImage:
            'repeating-linear-gradient(45deg, hsl(230 30% 9%) 0 8px, hsl(230 30% 7%) 8px 16px)',
        }}
      >
        <div className="grid grid-cols-3 md:grid-cols-6 gap-4 place-items-end">
          {seated.map((a, i) => (
            <Desk key={i} seatIndex={i} agent={a} />
          ))}
        </div>
        {overflow > 0 && (
          <div className="mt-3 text-center text-[10px] text-muted-foreground">
            +{overflow} ajan kuyrukta
          </div>
        )}
      </div>
    </div>
  );
}
