import { cn } from '@/lib/utils';
import type { AgentEntry } from '@/types/pixelAgents';
import { STATE_COLOR_VAR, STATE_LABEL_TR } from '@/types/pixelAgents';

interface Props {
  agent: AgentEntry;
  bodyColor: string; // hsl var
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  walking?: boolean;
}

/**
 * Tiny CSS pixel character. Uses a 6x8 grid of div pixels.
 */
export function AgentSprite({ agent, bodyColor, size = 'md', showLabel = true, walking = false }: Props) {
  const px = size === 'sm' ? 3 : size === 'lg' ? 6 : 4;
  const stateVar = STATE_COLOR_VAR[agent.state];

  // 6 cols x 8 rows pattern
  // legend: 0 empty, 1 outline, 2 body, 3 face, 4 hair
  const pattern: number[][] = [
    [0,0,4,4,0,0],
    [0,4,4,4,4,0],
    [0,3,3,3,3,0],
    [0,3,1,3,1,0],
    [0,3,3,3,3,0],
    [0,2,2,2,2,0],
    [0,2,2,2,2,0],
    [0,2,0,0,2,0],
  ];

  const colorFor = (n: number) => {
    switch (n) {
      case 1: return 'hsl(0 0% 5%)';
      case 2: return bodyColor;
      case 3: return 'hsl(35 60% 78%)';
      case 4: return 'hsl(25 40% 25%)';
      default: return 'transparent';
    }
  };

  return (
    <div className={cn('flex flex-col items-center gap-1', walking && 'anim-walk')}>
      <div
        className="anim-bob"
        style={{
          display: 'grid',
          gridTemplateColumns: `repeat(6, ${px}px)`,
          gridTemplateRows: `repeat(8, ${px}px)`,
          filter: `drop-shadow(0 0 6px hsl(var(${stateVar}) / 0.7))`,
        }}
      >
        {pattern.flat().map((cell, i) => (
          <div key={i} style={{ width: px, height: px, background: colorFor(cell) }} />
        ))}
      </div>
      {showLabel && (
        <div className="flex flex-col items-center">
          <span
            className="px-1.5 py-0.5 text-[9px] font-pixel uppercase border"
            style={{
              color: `hsl(var(${stateVar}))`,
              borderColor: `hsl(var(${stateVar}) / 0.6)`,
              background: 'hsl(var(--surface-1) / 0.85)',
            }}
          >
            {STATE_LABEL_TR[agent.state]}
          </span>
          <span className="mt-0.5 text-[9px] text-muted-foreground truncate max-w-[80px]">
            {agent.role === 'main' ? '★ main' : agent.agentType || 'sub'}
          </span>
        </div>
      )}
    </div>
  );
}
