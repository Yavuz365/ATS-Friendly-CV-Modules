import { Link } from 'react-router-dom';
import { useAgentData } from '@/context/AgentDataContext';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';
import type { PixelAgentsSettings } from '@/types/pixelAgents';

interface Props {
  settings: PixelAgentsSettings;
  onChange: (patch: Partial<PixelAgentsSettings>) => void;
}

export function StatusBar({ settings, onChange }: Props) {
  const { connected, activeSessionId, agents } = useAgentData();

  return (
    <header className="bg-card border-b border-border">
      <div className="container mx-auto px-4 py-3 flex flex-wrap items-center gap-3 justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div
              className={cn(
                'w-3 h-3 rounded-full',
                connected ? 'bg-primary anim-blink' : 'bg-destructive'
              )}
              style={{ boxShadow: connected ? '0 0 10px hsl(var(--primary))' : undefined }}
            />
            <span className="font-pixel text-xs">
              {connected ? 'CANLI' : 'ÇEVRİMDIŞI'}
            </span>
          </div>
          <span className="text-[10px] text-muted-foreground font-pixel">
            OTURUM: {activeSessionId ? activeSessionId.slice(-8) : '—'}
          </span>
          <span className="text-[10px] text-muted-foreground font-pixel">
            AJAN: {agents.size}
          </span>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 border border-border rounded-sm p-1">
            <button
              onClick={() => onChange({ mode: 'demo' })}
              className={cn(
                'px-2 py-0.5 text-[10px] font-pixel rounded-sm',
                settings.mode === 'demo'
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              DEMO
            </button>
            <button
              onClick={() => onChange({ mode: 'live' })}
              className={cn(
                'px-2 py-0.5 text-[10px] font-pixel rounded-sm',
                settings.mode === 'live'
                  ? 'bg-accent text-accent-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              CANLI SSE
            </button>
          </div>

          <label className="flex items-center gap-2 text-[10px] font-pixel">
            HERKESE AÇIK
            <Switch
              checked={settings.broadcast}
              onCheckedChange={(v) => onChange({ broadcast: v })}
            />
          </label>

          <Link
            to="/kurulum"
            className="text-[10px] font-pixel px-2 py-1 border border-border rounded-sm hover:border-primary hover:text-primary"
          >
            KURULUM →
          </Link>
        </div>
      </div>
    </header>
  );
}
