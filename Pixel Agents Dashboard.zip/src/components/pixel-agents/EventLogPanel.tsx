import { useAgentData } from '@/context/AgentDataContext';

const KIND_COLOR: Record<string, string> = {
  snapshot: 'hsl(var(--state-thinking))',
  agent_update: 'hsl(var(--state-running))',
  agent_end: 'hsl(var(--state-waiting))',
  session_change: 'hsl(var(--state-spawning))',
  connection: 'hsl(var(--primary))',
};

export function EventLogPanel() {
  const { log } = useAgentData();
  return (
    <div className="bg-card border border-border rounded-md p-4 scanlines">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-pixel text-xs">// SON OLAYLAR</h3>
        <span className="text-[10px] text-muted-foreground">{log.length}</span>
      </div>
      <div className="flex flex-col gap-1 max-h-[260px] overflow-y-auto font-mono text-[10px]">
        {log.length === 0 && <span className="text-muted-foreground italic">—</span>}
        {log.map((e) => (
          <div key={e.id} className="flex gap-2">
            <span className="text-muted-foreground/70 shrink-0">
              {new Date(e.ts).toLocaleTimeString()}
            </span>
            <span style={{ color: KIND_COLOR[e.kind] }} className="shrink-0 uppercase">
              {e.kind}
            </span>
            <span className="text-foreground/90 truncate">{e.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
