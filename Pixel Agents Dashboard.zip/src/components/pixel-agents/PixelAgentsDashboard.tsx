import { usePixelAgentsSettings } from '@/hooks/usePixelAgentsSettings';
import { AgentDataProvider } from '@/context/AgentDataContext';
import { useDemoAgentStream } from '@/hooks/useDemoAgentStream';
import { useSseAgentStream } from '@/hooks/useSseAgentStream';
import { StatusBar } from './StatusBar';
import { DeskCanvas } from './DeskCanvas';
import { OfficeCanvas } from './OfficeCanvas';
import { AgentActivityPanel } from './AgentActivityPanel';
import { EventLogPanel } from './EventLogPanel';

function DashboardInner() {
  const { settings, update } = usePixelAgentsSettings();

  useDemoAgentStream(settings.mode === 'demo');
  const { error } = useSseAgentStream(settings.mode === 'live', settings.streamUrl);

  return (
    <div className="min-h-screen flex flex-col">
      <StatusBar settings={settings} onChange={update} />

      {settings.mode === 'live' && error && (
        <div className="bg-destructive/10 border-b border-destructive/40 text-destructive text-xs px-4 py-2 text-center">
          {error}
        </div>
      )}

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 flex flex-col gap-6">
            <DeskCanvas />
            <OfficeCanvas />
          </div>
          <div className="flex flex-col gap-6">
            <AgentActivityPanel />
            <EventLogPanel />
          </div>
        </div>

        <footer className="mt-8 text-center text-[10px] text-muted-foreground font-pixel">
          PIXEL AGENTS · Claude Code görselleştirme · Lovable uyarlaması
        </footer>
      </main>
    </div>
  );
}

export function PixelAgentsDashboard() {
  return (
    <AgentDataProvider>
      <DashboardInner />
    </AgentDataProvider>
  );
}
