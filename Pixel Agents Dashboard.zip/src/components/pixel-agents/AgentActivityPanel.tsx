import { useAgentData } from '@/context/AgentDataContext';
import { STATE_COLOR_VAR, STATE_LABEL_TR } from '@/types/pixelAgents';

function formatAge(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  if (diff < 1000) return 'şimdi';
  if (diff < 60_000) return `${Math.floor(diff / 1000)}s`;
  return `${Math.floor(diff / 60_000)}d`;
}

export function AgentActivityPanel() {
  const { agents } = useAgentData();
  const list = Array.from(agents.values()).sort((a, b) =>
    a.role === b.role ? a.agentId.localeCompare(b.agentId) : a.role === 'main' ? -1 : 1
  );

  return (
    <div className="bg-card border border-border rounded-md p-4 scanlines">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-pixel text-xs">// AKTİF AJANLAR</h3>
        <span className="text-[10px] text-muted-foreground">{list.length}</span>
      </div>
      <div className="flex flex-col gap-2 max-h-[420px] overflow-y-auto">
        {list.length === 0 && (
          <div className="text-xs text-muted-foreground italic">Henüz ajan yok…</div>
        )}
        {list.map((a) => {
          const v = STATE_COLOR_VAR[a.state];
          return (
            <div
              key={a.agentId}
              className="border border-border/70 rounded-sm p-2 flex flex-col gap-1"
              style={{ background: 'hsl(var(--surface-2) / 0.7)' }}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className="w-2 h-2 rounded-full anim-blink"
                    style={{ background: `hsl(var(${v}))` }}
                  />
                  <span className="text-[11px] font-pixel truncate">
                    {a.role === 'main' ? '★ main' : a.agentType || 'sub'}
                  </span>
                </div>
                <span
                  className="text-[9px] font-pixel px-1.5 py-0.5"
                  style={{
                    color: `hsl(var(${v}))`,
                    border: `1px solid hsl(var(${v}) / 0.5)`,
                  }}
                >
                  {STATE_LABEL_TR[a.state]}
                </span>
              </div>
              <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                <span className="truncate">
                  {a.tool ? `${a.tool} · ` : ''}
                  {a.detail || '—'}
                </span>
                <span>{formatAge(a.lastSeen)}</span>
              </div>
              <div className="text-[9px] text-muted-foreground/70 truncate">
                {a.agentId}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
