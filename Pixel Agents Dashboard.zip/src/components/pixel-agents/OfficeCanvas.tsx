import { useAgentData } from '@/context/AgentDataContext';
import { AgentSprite } from './AgentSprite';
import type { AgentEntry, MultiAgentState } from '@/types/pixelAgents';

const ZONES: { state: MultiAgentState; label: string; floor: number }[] = [
  { state: 'thinking', label: 'Düşünme Salonu', floor: 3 },
  { state: 'searching', label: 'Araştırma', floor: 3 },
  { state: 'reading', label: 'Kütüphane', floor: 2 },
  { state: 'editing', label: 'Atölye', floor: 2 },
  { state: 'running', label: 'Sunucu Odası', floor: 1 },
  { state: 'waiting', label: 'Mola', floor: 1 },
  { state: 'spawning', label: 'Lobi', floor: 0 },
  { state: 'idle', label: 'Lobi', floor: 0 },
];

const FLOORS = [3, 2, 1, 0];

function Zone({
  state,
  label,
  agents,
}: {
  state: MultiAgentState;
  label: string;
  agents: AgentEntry[];
}) {
  return (
    <div
      className="flex-1 min-w-0 border border-border/60 rounded-sm p-2 flex flex-col gap-1"
      style={{ background: 'hsl(var(--surface-2) / 0.6)' }}
    >
      <div className="flex items-center justify-between">
        <span className="text-[9px] font-pixel uppercase text-muted-foreground truncate">{label}</span>
        <span className="text-[9px] text-muted-foreground">{agents.length}</span>
      </div>
      <div className="flex flex-wrap gap-2 items-end min-h-[44px]">
        {agents.map((a) => (
          <AgentSprite
            key={a.agentId}
            agent={a}
            bodyColor={a.role === 'main' ? 'hsl(160 84% 52%)' : 'hsl(280 80% 65%)'}
            size="sm"
            showLabel={false}
          />
        ))}
      </div>
    </div>
  );
}

export function OfficeCanvas() {
  const { agents } = useAgentData();
  const list = Array.from(agents.values());

  return (
    <div className="bg-card border border-border rounded-md p-4 scanlines">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-pixel text-xs">// OFİS GÖRÜNÜMÜ</h3>
        <span className="text-[10px] text-muted-foreground">{FLOORS.length} kat</span>
      </div>
      <div
        className="rounded-sm p-3 flex flex-col gap-2"
        style={{
          background:
            'linear-gradient(180deg, hsl(220 40% 8%), hsl(230 40% 5%))',
        }}
      >
        {FLOORS.map((floor) => {
          const zones = ZONES.filter((z) => z.floor === floor);
          return (
            <div key={floor} className="flex items-stretch gap-2">
              <div className="w-8 flex items-center justify-center font-pixel text-[10px] text-primary border border-border rounded-sm">
                F{floor}
              </div>
              <div className="flex gap-2 flex-1">
                {zones.map((z) => (
                  <Zone
                    key={z.state + z.label}
                    state={z.state}
                    label={z.label}
                    agents={list.filter((a) => a.state === z.state)}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
