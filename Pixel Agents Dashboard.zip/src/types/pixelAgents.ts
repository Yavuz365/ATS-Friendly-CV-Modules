export type AgentRole = 'main' | 'sub';

export type MultiAgentState =
  | 'idle'
  | 'reading'
  | 'editing'
  | 'running'
  | 'searching'
  | 'thinking'
  | 'waiting'
  | 'spawning';

export interface AgentEntry {
  agentId: string;
  role: AgentRole;
  sessionId: string;
  state: MultiAgentState;
  tool?: string;
  detail?: string;
  lastSeen: string;
  agentType?: string;
}

export interface AgentUpdatePayload {
  agentId: string;
  role: AgentRole;
  sessionId: string;
  state: MultiAgentState;
  tool?: string;
  detail?: string;
  timestamp?: string;
  agentType?: string;
}

export interface BroadcastSettings {
  broadcast: boolean;
  showPaths: boolean;
}

export type AppMode = 'demo' | 'live';

export interface PixelAgentsSettings {
  mode: AppMode;
  streamUrl: string;
  broadcast: boolean;
  showPaths: boolean;
}

export interface LogEvent {
  id: string;
  ts: string;
  kind: 'snapshot' | 'agent_update' | 'agent_end' | 'session_change' | 'connection';
  message: string;
}

export const STATE_COLOR_VAR: Record<MultiAgentState, string> = {
  idle: '--state-idle',
  thinking: '--state-thinking',
  reading: '--state-reading',
  editing: '--state-editing',
  running: '--state-running',
  searching: '--state-searching',
  waiting: '--state-waiting',
  spawning: '--state-spawning',
};

export const STATE_LABEL_TR: Record<MultiAgentState, string> = {
  idle: 'Boşta',
  thinking: 'Düşünüyor',
  reading: 'Okuyor',
  editing: 'Düzenliyor',
  running: 'Çalıştırıyor',
  searching: 'Arıyor',
  waiting: 'Bekliyor',
  spawning: 'Alt ajan',
};

export function mapToolToState(tool?: string): MultiAgentState {
  if (!tool) return 'thinking';
  switch (tool) {
    case 'Read': return 'reading';
    case 'Edit':
    case 'Write':
    case 'NotebookEdit': return 'editing';
    case 'Bash': return 'running';
    case 'Grep':
    case 'Glob':
    case 'WebFetch':
    case 'WebSearch': return 'searching';
    case 'Agent': return 'spawning';
    default: return 'running';
  }
}
