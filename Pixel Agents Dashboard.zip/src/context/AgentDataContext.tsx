import { createContext, useContext, useReducer, useCallback, ReactNode, useMemo } from 'react';
import type { AgentEntry, AgentUpdatePayload, LogEvent } from '@/types/pixelAgents';

interface State {
  agents: Map<string, AgentEntry>;
  connected: boolean;
  activeSessionId: string | null;
  log: LogEvent[];
}

type Action =
  | { type: 'connected'; value: boolean }
  | { type: 'snapshot'; entries: AgentEntry[] }
  | { type: 'update'; payload: AgentUpdatePayload }
  | { type: 'agent_end'; agentId: string }
  | { type: 'session_change'; sessionId: string }
  | { type: 'log'; entry: LogEvent }
  | { type: 'reset' };

const initial: State = {
  agents: new Map(),
  connected: false,
  activeSessionId: null,
  log: [],
};

function pushLog(log: LogEvent[], entry: LogEvent): LogEvent[] {
  const next = [entry, ...log];
  return next.slice(0, 80);
}

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'connected':
      return {
        ...state,
        connected: action.value,
        log: pushLog(state.log, {
          id: crypto.randomUUID(),
          ts: new Date().toISOString(),
          kind: 'connection',
          message: action.value ? 'Bağlandı' : 'Bağlantı kesildi',
        }),
      };
    case 'snapshot': {
      const m = new Map<string, AgentEntry>();
      for (const a of action.entries) m.set(a.agentId, a);
      return {
        ...state,
        agents: m,
        log: pushLog(state.log, {
          id: crypto.randomUUID(),
          ts: new Date().toISOString(),
          kind: 'snapshot',
          message: `Anlık görüntü: ${action.entries.length} ajan`,
        }),
      };
    }
    case 'update': {
      const m = new Map(state.agents);
      const existing = m.get(action.payload.agentId);
      m.set(action.payload.agentId, {
        agentId: action.payload.agentId,
        role: action.payload.role,
        sessionId: action.payload.sessionId,
        state: action.payload.state,
        tool: action.payload.tool ?? existing?.tool,
        detail: action.payload.detail ?? existing?.detail,
        agentType: action.payload.agentType ?? existing?.agentType,
        lastSeen: action.payload.timestamp ?? new Date().toISOString(),
      });
      return {
        ...state,
        agents: m,
        activeSessionId: state.activeSessionId ?? action.payload.sessionId,
        log: pushLog(state.log, {
          id: crypto.randomUUID(),
          ts: new Date().toISOString(),
          kind: 'agent_update',
          message: `${action.payload.role}:${action.payload.agentId.slice(0, 6)} → ${action.payload.state}${action.payload.tool ? ` (${action.payload.tool})` : ''}`,
        }),
      };
    }
    case 'agent_end': {
      const m = new Map(state.agents);
      m.delete(action.agentId);
      return {
        ...state,
        agents: m,
        log: pushLog(state.log, {
          id: crypto.randomUUID(),
          ts: new Date().toISOString(),
          kind: 'agent_end',
          message: `Ajan sonlandı: ${action.agentId.slice(0, 8)}`,
        }),
      };
    }
    case 'session_change':
      return {
        ...state,
        agents: new Map(),
        activeSessionId: action.sessionId,
        log: pushLog(state.log, {
          id: crypto.randomUUID(),
          ts: new Date().toISOString(),
          kind: 'session_change',
          message: `Oturum değişti: ${action.sessionId.slice(0, 8)}`,
        }),
      };
    case 'reset':
      return initial;
    default:
      return state;
  }
}

interface ContextValue extends State {
  setConnected: (v: boolean) => void;
  applySnapshot: (entries: AgentEntry[]) => void;
  applyUpdate: (p: AgentUpdatePayload) => void;
  endAgent: (id: string) => void;
  changeSession: (id: string) => void;
  reset: () => void;
}

const AgentDataContext = createContext<ContextValue | null>(null);

export function AgentDataProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initial);

  const setConnected = useCallback((v: boolean) => dispatch({ type: 'connected', value: v }), []);
  const applySnapshot = useCallback((entries: AgentEntry[]) => dispatch({ type: 'snapshot', entries }), []);
  const applyUpdate = useCallback((payload: AgentUpdatePayload) => dispatch({ type: 'update', payload }), []);
  const endAgent = useCallback((agentId: string) => dispatch({ type: 'agent_end', agentId }), []);
  const changeSession = useCallback((sessionId: string) => dispatch({ type: 'session_change', sessionId }), []);
  const reset = useCallback(() => dispatch({ type: 'reset' }), []);

  const value = useMemo(
    () => ({ ...state, setConnected, applySnapshot, applyUpdate, endAgent, changeSession, reset }),
    [state, setConnected, applySnapshot, applyUpdate, endAgent, changeSession, reset]
  );

  return <AgentDataContext.Provider value={value}>{children}</AgentDataContext.Provider>;
}

export function useAgentData() {
  const ctx = useContext(AgentDataContext);
  if (!ctx) throw new Error('useAgentData must be used within AgentDataProvider');
  return ctx;
}
