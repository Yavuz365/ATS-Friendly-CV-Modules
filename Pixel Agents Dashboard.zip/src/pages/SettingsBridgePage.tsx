import { useState } from 'react';
import { Link } from 'react-router-dom';
import { usePixelAgentsSettings } from '@/hooks/usePixelAgentsSettings';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

type TestState = 'idle' | 'testing' | 'ok' | 'fail';

export default function SettingsBridgePage() {
  const { settings, update } = usePixelAgentsSettings();
  const [test, setTest] = useState<TestState>('idle');
  const [testMessage, setTestMessage] = useState('');

  function testConnection() {
    setTest('testing');
    setTestMessage('Bağlanıyor…');
    let es: EventSource | null = null;
    try {
      es = new EventSource(settings.streamUrl);
    } catch (e) {
      setTest('fail');
      setTestMessage('Geçersiz URL: ' + (e as Error).message);
      return;
    }
    const timeout = setTimeout(() => {
      setTest('fail');
      setTestMessage('5 sn içinde yanıt yok. Köprünün çalıştığından emin olun.');
      es?.close();
    }, 5000);
    es.onopen = () => {
      clearTimeout(timeout);
      setTest('ok');
      setTestMessage('Bağlantı başarılı.');
      es?.close();
    };
    es.onerror = () => {
      clearTimeout(timeout);
      setTest('fail');
      setTestMessage('Bağlantı başarısız. CORS/URL/köprü çalışıyor mu?');
      es?.close();
    };
  }

  const yamlExample = `services:
  pixel-agents:
    build: .
    ports:
      - "3000:3000"
    environment:
      CLAUDE_JSONL_DIR: /dot-claude/projects/-root
    volumes:
      - ~/.claude:/dot-claude:ro`;

  return (
    <div className="min-h-screen container mx-auto px-4 py-8 max-w-3xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-pixel text-lg">// KURULUM / KÖPRÜ</h1>
        <Link to="/" className="text-[10px] font-pixel px-2 py-1 border border-border rounded-sm hover:border-primary hover:text-primary">
          ← PANO
        </Link>
      </div>

      <p className="text-sm text-muted-foreground mb-6">
        Lovable üzerinde çalışan bu uygulama görsel panodur. Gerçek Claude Code
        verileri için yerel veya sunucu tarafında bir <strong>köprü</strong> çalıştırmanız
        gerekir. Köprü, <code>~/.claude</code> klasörünüzdeki <code>.jsonl</code> oturum
        dosyalarını okur ve SSE üzerinden bu panoya yayınlar.
      </p>

      <section className="bg-card border border-border rounded-md p-4 mb-6 scanlines">
        <h2 className="font-pixel text-xs mb-4">// AYARLAR</h2>

        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <Label className="text-xs">Mod</Label>
            <div className="flex items-center gap-2 text-xs">
              <span className={settings.mode === 'demo' ? 'text-primary' : 'text-muted-foreground'}>Demo</span>
              <Switch
                checked={settings.mode === 'live'}
                onCheckedChange={(v) => update({ mode: v ? 'live' : 'demo' })}
              />
              <span className={settings.mode === 'live' ? 'text-accent' : 'text-muted-foreground'}>Canlı SSE</span>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <Label htmlFor="stream-url" className="text-xs">SSE Akış URL'si</Label>
            <Input
              id="stream-url"
              value={settings.streamUrl}
              onChange={(e) => update({ streamUrl: e.target.value })}
              placeholder="http://localhost:3000/api/pixel-agents/agents-stream"
              className="font-mono text-xs"
            />
          </div>

          <div className="flex items-center justify-between">
            <Label className="text-xs">Herkese Açık Yayın</Label>
            <Switch
              checked={settings.broadcast}
              onCheckedChange={(v) => update({ broadcast: v })}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label className="text-xs">Dosya Yollarını Göster</Label>
            <Switch
              checked={settings.showPaths}
              onCheckedChange={(v) => update({ showPaths: v })}
            />
          </div>

          <div className="flex items-center gap-3">
            <Button onClick={testConnection} disabled={test === 'testing'}>
              Bağlantıyı Test Et
            </Button>
            {testMessage && (
              <span
                className="text-xs"
                style={{
                  color:
                    test === 'ok'
                      ? 'hsl(var(--primary))'
                      : test === 'fail'
                      ? 'hsl(var(--destructive))'
                      : 'hsl(var(--muted-foreground))',
                }}
              >
                {testMessage}
              </span>
            )}
          </div>
        </div>
      </section>

      <section className="bg-card border border-border rounded-md p-4 mb-6">
        <h2 className="font-pixel text-xs mb-3">// KÖPRÜYÜ DOCKER İLE ÇALIŞTIR</h2>
        <ol className="list-decimal list-inside text-sm space-y-2 text-muted-foreground">
          <li>
            Repoyu klonla:{' '}
            <code className="text-foreground">git clone https://github.com/Yavuz365/pixel-agents.git</code>
          </li>
          <li>
            Docker + Docker Compose kurulu olmalı ve Claude Code aynı makinede çalışmalıdır.
          </li>
          <li>
            <code className="text-foreground">CLAUDE_JSONL_DIR</code> değişkenini Claude Code'un oturum
            dizinine eşle.
          </li>
          <li>
            <code className="text-foreground">docker compose up -d</code> ile başlat.
          </li>
          <li>
            Bu uygulamada SSE URL alanını köprünün <code>/api/pixel-agents/agents-stream</code> ucuna ayarla.
          </li>
        </ol>

        <pre className="mt-4 text-[11px] bg-secondary border border-border rounded-sm p-3 overflow-x-auto whitespace-pre">
{yamlExample}
        </pre>
      </section>

      <section className="bg-card border border-border rounded-md p-4">
        <h2 className="font-pixel text-xs mb-3">// YOL DÖNÜŞÜMÜ ÖRNEKLERİ</h2>
        <ul className="text-sm space-y-1 font-mono text-muted-foreground">
          <li><span className="text-foreground">~/</span> → /dot-claude/projects/-root</li>
          <li><span className="text-foreground">~/myproject</span> → /dot-claude/projects/-home-youruser-myproject</li>
          <li><span className="text-foreground">/Users/john/work</span> → /dot-claude/projects/-Users-john-work</li>
        </ul>
        <p className="mt-4 text-xs text-muted-foreground">
          Not: Lovable barındırılan ön yüz tarayıcıdan doğrudan <code>~/.claude</code>'u
          okuyamaz. Bu yüzden köprü gereklidir. Köprünüz HTTPS sunmuyorsa, tarayıcınız
          mixed-content nedeniyle engelleyebilir; yerel geliştirmede HTTP origin (örn.{' '}
          <code>localhost</code>) önerilir veya köprüye TLS ekleyin.
        </p>
      </section>
    </div>
  );
}
