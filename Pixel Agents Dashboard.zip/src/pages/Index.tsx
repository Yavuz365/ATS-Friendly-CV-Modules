import { PixelAgentsDashboard } from '@/components/pixel-agents/PixelAgentsDashboard';

const Index = () => <PixelAgentsDashboard />;

export default Index;
