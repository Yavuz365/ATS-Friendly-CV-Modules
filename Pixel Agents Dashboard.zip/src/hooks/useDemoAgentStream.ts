import { useEffect, useRef } from 'react';
import { useAgentData } from '@/context/AgentDataContext';
import type { AgentEntry, MultiAgentState } from '@/types/pixelAgents';

const STATES: MultiAgentState[] = ['reading', 'editing', 'running', 'searching', 'thinking', 'waiting'];
const TOOLS: Record<MultiAgentState, string | undefined> = {
  idle: undefined,
  thinking: undefined,
  reading: 'Read',
  editing: 'Edit',
  running: 'Bash',
  searching: 'Grep',
  waiting: undefined,
  spawning: 'Agent',
};
const DETAILS: Record<MultiAgentState, string[]> = {
  idle: ['—'],
  thinking: ['planlıyor', 'analiz ediyor', 'cevap hazırlıyor'],
  reading: ['src/App.tsx', 'package.json', 'README.md', 'tailwind.config.ts'],
  editing: ['src/pages/Index.tsx', 'src/components/Card.tsx', 'index.css'],
  running: ['npm run build', 'git status', 'bun test', 'tsc --noEmit'],
  searching: ['rg "useEffect"', 'glob **/*.ts', 'web: react 19 docs'],
  waiting: ['kullanıcı yanıtı', 'onay bekleniyor'],
  spawning: ['code-reviewer', 'researcher', 'tester'],
};

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function useDemoAgentStream(enabled: boolean) {
  const { setConnected, applySnapshot, applyUpdate, endAgent, changeSession } = useAgentData();
  const agentsRef = useRef<AgentEntry[]>([]);

  useEffect(() => {
    if (!enabled) return;

    const sessionId = 'demo-' + crypto.randomUUID();
    changeSession(sessionId);
    setConnected(true);

    const main: AgentEntry = {
      agentId: 'main-' + crypto.randomUUID().slice(0, 8),
      role: 'main',
      sessionId,
      state: 'thinking',
      tool: undefined,
      detail: 'oturum başlatılıyor',
      lastSeen: new Date().toISOString(),
    };

    const subs: AgentEntry[] = Array.from({ length: 2 }).map((_, i) => ({
      agentId: `sub-${i}-${crypto.randomUUID().slice(0, 6)}`,
      role: 'sub',
      sessionId,
      state: pick(STATES),
      tool: undefined,
      detail: undefined,
      lastSeen: new Date().toISOString(),
      agentType: pick(['researcher', 'code-reviewer', 'tester', 'planner']),
    }));

    agentsRef.current = [main, ...subs];
    applySnapshot(agentsRef.current);

    const tick = setInterval(() => {
      const list = agentsRef.current;
      if (list.length === 0) return;
      const target = pick(list);
      const newState = pick(STATES);
      applyUpdate({
        agentId: target.agentId,
        role: target.role,
        sessionId: target.sessionId,
        state: newState,
        tool: TOOLS[newState],
        detail: pick(DETAILS[newState]),
        agentType: target.agentType,
        timestamp: new Date().toISOString(),
      });
      target.state = newState;
    }, 1800);

    const lifecycle = setInterval(() => {
      const subsAlive = agentsRef.current.filter((a) => a.role === 'sub');
      if (subsAlive.length < 5 && Math.random() < 0.55) {
        const newSub: AgentEntry = {
          agentId: `sub-${crypto.randomUUID().slice(0, 8)}`,
          role: 'sub',
          sessionId,
          state: 'spawning',
          tool: 'Agent',
          detail: pick(DETAILS.spawning),
          lastSeen: new Date().toISOString(),
          agentType: pick(['researcher', 'code-reviewer', 'tester', 'planner']),
        };
        agentsRef.current = [...agentsRef.current, newSub];
        applyUpdate({
          agentId: newSub.agentId,
          role: newSub.role,
          sessionId,
          state: 'spawning',
          tool: 'Agent',
          detail: newSub.detail,
          agentType: newSub.agentType,
          timestamp: new Date().toISOString(),
        });
      } else if (subsAlive.length > 2 && Math.random() < 0.4) {
        const victim = pick(subsAlive);
        agentsRef.current = agentsRef.current.filter((a) => a.agentId !== victim.agentId);
        endAgent(victim.agentId);
      }
    }, 6500);

    return () => {
      clearInterval(tick);
      clearInterval(lifecycle);
      setConnected(false);
    };
  }, [enabled, setConnected, applySnapshot, applyUpdate, endAgent, changeSession]);
}
