import { useCallback, useEffect, useState } from 'react';
import type { PixelAgentsSettings } from '@/types/pixelAgents';

const KEY = 'pixel-agents:settings';
const DEFAULTS: PixelAgentsSettings = {
  mode: 'demo',
  streamUrl: 'http://localhost:3000/api/pixel-agents/agents-stream',
  broadcast: false,
  showPaths: false,
};

export function usePixelAgentsSettings() {
  const [settings, setSettings] = useState<PixelAgentsSettings>(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return DEFAULTS;
      return { ...DEFAULTS, ...JSON.parse(raw) };
    } catch {
      return DEFAULTS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(settings));
    } catch {
      /* ignore */
    }
  }, [settings]);

  const update = useCallback((patch: Partial<PixelAgentsSettings>) => {
    setSettings((s) => ({ ...s, ...patch }));
  }, []);

  return { settings, update };
}
