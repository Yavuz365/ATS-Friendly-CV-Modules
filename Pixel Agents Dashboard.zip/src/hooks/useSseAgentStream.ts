import { useEffect, useState } from 'react';
import { useAgentData } from '@/context/AgentDataContext';
import type { AgentEntry, AgentUpdatePayload } from '@/types/pixelAgents';

export function useSseAgentStream(enabled: boolean, url: string) {
  const { setConnected, applySnapshot, applyUpdate, endAgent, changeSession } = useAgentData();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!enabled || !url) return;
    setError(null);
    let es: EventSource | null = null;
    try {
      es = new EventSource(url);
    } catch (e) {
      setError((e as Error).message);
      setConnected(false);
      return;
    }

    es.onopen = () => setConnected(true);
    es.onerror = () => {
      setConnected(false);
      setError('SSE bağlantı hatası. URL ve köprüyü kontrol edin.');
    };

    es.addEventListener('snapshot', (e: MessageEvent) => {
      try {
        const data = JSON.parse(e.data);
        const arr: AgentEntry[] = Array.isArray(data) ? data : (data.agents ?? []);
        applySnapshot(arr);
      } catch { /* ignore */ }
    });

    es.addEventListener('session_change', (e: MessageEvent) => {
      try {
        const { sessionId } = JSON.parse(e.data);
        if (sessionId) changeSession(sessionId);
      } catch { /* ignore */ }
    });

    es.addEventListener('agent_update', (e: MessageEvent) => {
      try {
        const payload: AgentUpdatePayload = JSON.parse(e.data);
        applyUpdate(payload);
      } catch { /* ignore */ }
    });

    es.addEventListener('agent_end', (e: MessageEvent) => {
      try {
        const { agentId } = JSON.parse(e.data);
        if (agentId) endAgent(agentId);
      } catch { /* ignore */ }
    });

    return () => {
      es?.close();
      setConnected(false);
    };
  }, [enabled, url, setConnected, applySnapshot, applyUpdate, endAgent, changeSession]);

  return { error };
}
